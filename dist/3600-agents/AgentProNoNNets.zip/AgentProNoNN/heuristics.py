"""
Heuristics and Move Evaluation for AgentB

This module contains strategic evaluation functions for moves and positions.
"""

from typing import Tuple, List
from game.enums import Direction, MoveType, loc_after_direction
import game.board as board_module


class MoveEvaluator:
    """
    Evaluates moves and positions using heuristic knowledge.
    """

    def __init__(self, map_size: int = 8):
        self.map_size = map_size

    def quick_evaluate_move(
        self,
        move: Tuple[Direction, MoveType],
        board: board_module.Board,
        trapdoor_tracker=None,
        visited_squares=None,
        recent_positions=None,
        blocked_locations=None,
        just_respawned=False,
        is_oscillating=False,
        current_turn_count=0
    ) -> float:
        """
        Quick heuristic evaluation of a move for move ordering.

        This is used to order moves before searching, improving alpha-beta pruning.
        """
        direction, move_type = move
        my_loc = board.chicken_player.get_location()
        new_loc = loc_after_direction(my_loc, direction)
        enemy_loc = board.chicken_enemy.get_location()

        score = 0.0

        # 0. OPPONENT AVOIDANCE: Stay away from enemy to maximize freedom!
        # REDUCED rewards to prevent circular orbit patterns
        dist_to_enemy = abs(new_loc[0] - enemy_loc[0]) + abs(new_loc[1] - enemy_loc[1])

        # Moderate bonus for staying far from opponent (reduced from 400/300/200)
        if dist_to_enemy >= 6:
            score += 80.0  # Very far - maximum freedom (was 400)
        elif dist_to_enemy >= 5:
            score += 60.0  # Far - good freedom (was 300)
        elif dist_to_enemy >= 4:
            score += 40.0  # Moderate distance (was 200)
        elif dist_to_enemy >= 3:
            score += 20.0  # Some distance (was 100)
        elif dist_to_enemy <= 2:
            score -= 150.0  # Too close - danger of blocking! (was 300)

        # EXPLORATION SPREADING: Strongly prefer moving to unexplored quadrants
        # Divide map into 4 quadrants and spread out
        if visited_squares is not None and len(visited_squares) > 0:
            # Calculate which quadrant is least explored
            quadrant_visits = self._count_quadrant_visits(new_loc, visited_squares)
            current_quadrant_visits = quadrant_visits.get(self._get_quadrant(new_loc), 0)
            total_visits = sum(quadrant_visits.values())

            if total_visits > 0:
                # Bonus for moving to less-explored quadrants
                exploration_ratio = 1.0 - (current_quadrant_visits / total_visits)
                score += exploration_ratio * 300.0  # Up to +300 for unexplored quadrants

        # 0.5. MASSIVE penalty for blocked locations (enemy eggs/barriers)
        # This prevents wasting turns by repeatedly hitting the same barrier
        if blocked_locations is not None and new_loc in blocked_locations:
            score -= 50000.0  # Extremely strong penalty - never waste a turn on a known barrier
        
        # Also check if board says it's blocked (catches newly placed enemy eggs/turds)
        if board.is_cell_blocked(new_loc):
            score -= 50000.0  # Same penalty for currently blocked locations

        # 0. ENDGAME BONUS: Eggs are MORE valuable near end of game!
        # Game ends at turn 40, so maximize eggs in last 10 turns
        turns_left = getattr(board, 'turns_left_player', 40)
        endgame_multiplier = 1.0
        if turns_left <= 10:
            # Last 10 turns: eggs are 3x more valuable!
            endgame_multiplier = 3.0
        elif turns_left <= 20:
            # Last 20 turns: eggs are 2x more valuable
            endgame_multiplier = 2.0

        # 1. Egg moves are HIGHLY valuable (direct scoring) - EMPHASIZED!
        if move_type == MoveType.EGG:
            score += 5000.0 * endgame_multiplier  # MASSIVE bonus - eggs are THE PRIMARY GOAL!

            # DESPERATION BONUS: When we have few valid moves (trapped in corner), ALWAYS lay eggs!
            my_valid_moves = len(board.get_valid_moves())
            if my_valid_moves <= 3:
                score += 10000.0  # DESPERATE - lay eggs when trapped!
            elif my_valid_moves <= 5:
                score += 5000.0  # Limited mobility - prioritize eggs!

            # Bonus for laying eggs in new/unexplored areas - encourages spreading eggs
            # Check if visited_squares is dict (timestamp-based) or set (legacy)
            if visited_squares is None:
                score += 300.0  # No tracking - assume new
            elif isinstance(visited_squares, dict):
                # Timestamp-based: check recency
                if new_loc not in visited_squares:
                    score += 300.0  # Completely new area
                else:
                    # Check how long ago it was visited
                    turns_since_visit = current_turn_count - visited_squares.get(new_loc, 0)
                    if turns_since_visit > 10:
                        score += 200.0  # Visited long ago - okay
                    elif turns_since_visit > 5:
                        score += 100.0  # Visited recently - light bonus
                    else:
                        score += 50.0  # Very recently visited - minimal bonus
            elif new_loc not in visited_squares:
                score += 300.0  # Extra bonus for eggs in completely new areas
            else:
                # Even if visited before (walked through), still good to lay egg!
                score += 150.0  # Moderate bonus - it's okay to lay eggs on visited squares
            
            # ANTI-REPETITION FOR EGG MOVES: Apply penalties for recent positions
            if recent_positions is not None and len(recent_positions) > 0:
                if new_loc in recent_positions:
                    recent_index = recent_positions.index(new_loc)
                    recency_penalty = (len(recent_positions) - recent_index) * 200.0
                    score -= 500.0 + recency_penalty  # Penalty for laying egg where we just were
                    
                    # Extra penalty if this creates a loop
                    visit_count = recent_positions.count(new_loc)
                    if visit_count > 1:
                        score -= visit_count * 400.0

            # Check if there's already an egg here (shouldn't happen, but just in case)
            if hasattr(board, 'eggs_player') and new_loc in board.eggs_player:
                score -= 100000.0  # Can't lay egg where one already exists

            # Bonus for laying eggs far from existing eggs (spread out, don't cluster)
            if hasattr(board, 'eggs_player') and board.eggs_player:
                min_dist_to_existing_egg = min(
                    abs(new_loc[0] - egg[0]) + abs(new_loc[1] - egg[1])
                    for egg in board.eggs_player
                )
                # Bonus for spreading eggs out (farther from existing eggs = better)
                if min_dist_to_existing_egg >= 4:
                    score += 120.0  # Good spread bonus
                elif min_dist_to_existing_egg >= 3:
                    score += 60.0
                elif min_dist_to_existing_egg >= 2:
                    score += 30.0  # Even moderate distance is okay
                elif min_dist_to_existing_egg <= 1:
                    score -= 60.0  # Light penalty for clustering too close
            else:
                # First egg! Extra bonus
                score += 200.0

            # Corner eggs are MUCH better - they give 3 eggs instead of 1 (3x value!)
            # But only if this chicken can lay eggs on this corner (parity check)
            if self._is_corner(new_loc):
                # Check if this chicken can lay eggs on this corner
                can_lay_on_corner = board.chicken_player.can_lay_egg(new_loc)
                if can_lay_on_corner:
                    score += 800.0  # HUGE bonus for corner eggs! (3x value)
                else:
                    score += 50.0
            # Center eggs control the board
            if self._is_center(new_loc):
                score += 80.0

        # 1.5. POST-RESPAWN EXPLORATION: After hitting a trapdoor, strongly encourage exploring NEW areas!
        # Detect respawn: recent_positions is empty or very small
        recently_respawned = (recent_positions is None or len(recent_positions) <= 3)

        if just_respawned or recently_respawned:
            if move_type == MoveType.PLAIN:
                # STRONG bonus for exploring completely new squares after respawn
                if visited_squares is None or new_loc not in visited_squares:
                    score += 500.0  # HUGE bonus - go to new areas!
                else:
                    # Penalty for revisiting old squares (unless necessary)
                    score -= 300.0  # Discourage going back to old areas

                # EXTRA penalty for squares with our own eggs (can't lay another egg there)
                if hasattr(board, 'eggs_player') and new_loc in board.eggs_player:
                    score -= 800.0  # Strong penalty - that square is done!

            elif move_type == MoveType.EGG:
                # For egg moves: prefer unvisited squares even more!
                if visited_squares is None or new_loc not in visited_squares:
                    score += 1000.0  # MASSIVE bonus - new egg in new area!
                else:
                    # Still good to lay eggs in visited squares, but prefer new ones
                    score += 200.0  # Moderate bonus

        # 1.6. Plain moves that help exploration are valuable
        # Plain moves are necessary to reach new egg-laying locations
        # BUT: prioritize egg moves over plain moves when possible
        if move_type == MoveType.PLAIN:
            # Bonus for plain moves to new squares (helps exploration)
            if visited_squares is None:
                score += 40.0  # Good bonus for exploring via plain moves
            elif isinstance(visited_squares, dict):
                if new_loc not in visited_squares:
                    score += 40.0  # New square
                else:
                    # Check recency
                    turns_since_visit = current_turn_count - visited_squares.get(new_loc, 0)
                    if turns_since_visit > 10:
                        score += 20.0  # Old visit - okay
            elif new_loc not in visited_squares:
                score += 40.0  # Good bonus for exploring via plain moves
            # Small bonus for plain moves that get us closer to unexplored areas
            # (This encourages movement even when not laying eggs)

            # However, plain moves should be less valuable than egg moves
            # This is already the case since egg moves get +5000 base score

        # 2. Turd moves for strategic blocking
        elif move_type == MoveType.TURD:
            if board.chicken_player.get_turds_left() > 0:
                # Turds near enemy are valuable (blocking)
                dist_to_enemy = abs(new_loc[0] - enemy_loc[0]) + abs(new_loc[1] - enemy_loc[1])
                if dist_to_enemy <= 2:
                    score += 60.0
                elif dist_to_enemy <= 4:
                    score += 30.0

                # Blocking paths to valuable squares
                if self._blocks_valuable_square(new_loc, enemy_loc, board):
                    score += 40.0

        # 3. Avoid trapdoors! (CRITICAL - costs 4 eggs = 400 points!)
        # Egg moves give +300, so trapdoor penalty must be MUCH higher
        if trapdoor_tracker:
            danger = trapdoor_tracker.get_danger_score(new_loc)
            # Check if this is a known trapdoor
            is_known_trapdoor = new_loc in trapdoor_tracker.known_trapdoors
            
            if is_known_trapdoor:
                # ABSOLUTE penalty for known trapdoors - never go there!
                # This must be higher than any possible benefit (eggs, etc.)
                score -= 1000000.0
            else:
                # SCALED DOWN penalties (10-20x reduction) to prevent forbidden zones
                # Trapdoor costs 4 eggs = 400 points, so penalties should be proportional
                if danger > 0.2:  # 20% or more probability
                    score -= danger * 10000.0  # Reduced from 200000 (20x reduction)
                elif danger > 0.1:  # 10-20% probability
                    score -= danger * 5000.0  # Reduced from 100000 (20x reduction)
                elif danger > 0.05:  # 5-10% probability
                    score -= danger * 2500.0  # Reduced from 50000 (20x reduction)
                elif danger > 0.01:  # 1-5% probability
                    score -= danger * 1000.0  # Reduced from 20000 (20x reduction)
                else:
                    score -= danger * 500.0  # Reduced from 10000 (20x reduction)
            
            # 3.5. AVOID STAYING AROUND KNOWN TRAPDOORS - explore outwards!
            # Once we know where trapdoors are, move away from them
            # IMPORTANT: Egg moves get MUCH lighter penalties - we need to lay eggs!
            # Add pseudo-randomness based on location hash to break diamond patterns
            # This makes different escape directions more attractive without true randomness
            if trapdoor_tracker.known_trapdoors:
                min_dist_to_trapdoor = min(
                    abs(new_loc[0] - trap[0]) + abs(new_loc[1] - trap[1])
                    for trap in trapdoor_tracker.known_trapdoors
                )

                # REMOVED hash-based randomness - it causes unstable behavior and micro-loops
                # Use deterministic bonuses instead
                location_random = 1.0  # No variation
                escape_random = 1.0  # No variation
                exploration_random = 1.0  # No variation

                # EGG MOVES: Only penalize if VERY close (adjacent) - eggs are the goal!
                # PLAIN MOVES: LIGHT penalties for being near trapdoors (reduced to prevent loops!)
                if move_type == MoveType.EGG:
                    # For eggs, only penalize if immediately adjacent to trapdoor
                    if min_dist_to_trapdoor <= 1:
                        score -= 100.0  # Very light penalty - eggs are ALWAYS worth it!
                    # No other proximity penalties for egg moves - we need eggs!
                elif move_type == MoveType.PLAIN:
                    # PLAIN moves: REDUCED penalties (was causing too much oscillation)
                    if min_dist_to_trapdoor <= 1:
                        score -= 400.0  # Moderate penalty (was 2000!)
                    elif min_dist_to_trapdoor <= 2:
                        score -= 150.0  # Light penalty (was 800!)
                    # REMOVED distance 3 penalty - too restrictive!

                # BONUS for moving far away from known trapdoors (encourages exploration)
                # Apply to ALL move types to encourage spreading out
                # Add pseudo-randomness to make different escape directions more attractive
                if min_dist_to_trapdoor >= 5:
                    base_bonus = 400.0  # DOUBLED - strong bonus for getting far from trapdoors
                    score += base_bonus * escape_random
                elif min_dist_to_trapdoor >= 4:
                    base_bonus = 250.0  # INCREASED - good bonus
                    score += base_bonus * escape_random
                elif min_dist_to_trapdoor >= 3:
                    base_bonus = 120.0  # NEW - reward even moderate distance
                    score += base_bonus * escape_random

                # DIRECTIONAL ESCAPE: Reward moves that INCREASE distance from trapdoor
                # This creates a strong directional bias away from dangerous areas
                if my_loc is not None and min_dist_to_trapdoor <= 4:
                    # Find the closest trapdoor
                    closest_trap = min(
                        trapdoor_tracker.known_trapdoors,
                        key=lambda trap: abs(my_loc[0] - trap[0]) + abs(my_loc[1] - trap[1])
                    )

                    # Calculate distance from current location to closest trap
                    current_dist_to_trap = abs(my_loc[0] - closest_trap[0]) + abs(my_loc[1] - closest_trap[1])

                    # Calculate distance from new location to closest trap
                    new_dist_to_trap = abs(new_loc[0] - closest_trap[0]) + abs(new_loc[1] - closest_trap[1])

                    # Reward moves that increase distance (moving away)
                    if new_dist_to_trap > current_dist_to_trap:
                        distance_increase = new_dist_to_trap - current_dist_to_trap
                        score += distance_increase * 300.0  # STRONG directional escape bonus
                    # Penalize moves that decrease distance (moving toward)
                    elif new_dist_to_trap < current_dist_to_trap:
                        distance_decrease = current_dist_to_trap - new_dist_to_trap
                        score -= distance_decrease * 400.0  # Even stronger penalty for moving toward

                # EXTRA exploration bonus when moving away from trapdoors to new areas
                # Add significant pseudo-randomness to encourage varied exploration paths
                if min_dist_to_trapdoor >= 3:
                    if visited_squares is None or new_loc not in visited_squares:
                        # Strong bonus for exploring new areas away from trapdoors
                        # Add pseudo-randomness to break diamond patterns
                        score += 200.0 * exploration_random  # INCREASED
                    else:
                        # Even if visited, still give some bonus for moving away (with variation)
                        score += 80.0 * escape_random  # INCREASED

                # REMOVED pseudo-random exploration bonus - causes instability

        # 4. Positional factors
        # Moving toward center is good (more options)
        center_dist = self._distance_to_center(new_loc)
        score -= center_dist * 2.0

        # 5. Don't move into cramped positions
        if self._is_edge(new_loc):
            score -= 10.0
        
        # 6. Anti-repetition for PLAIN moves: heavily penalize tight loops
        # BUT: egg moves are exempt from most of this (eggs are the goal!)
        # ALSO: when trapped (few moves), reduce penalties to allow survival
        # CRITICAL: When oscillating, FORCE exploration by reducing ALL repetition penalties!
        if move_type == MoveType.PLAIN:
            # Check if we're trapped (few valid moves)
            my_valid_moves = len(board.get_valid_moves())
            desperation_factor = 1.0
            if is_oscillating:
                # OSCILLATING - drastically reduce ALL penalties to force exploration!
                desperation_factor = 0.01  # Almost zero penalties - must break the loop!
            elif my_valid_moves <= 3:
                desperation_factor = 0.1  # DRASTICALLY reduce penalties when desperate
            elif my_valid_moves <= 5:
                desperation_factor = 0.3  # Significantly reduce penalties when limited

            if recent_positions is not None and len(recent_positions) > 0:
                # Check if this location was visited recently (last 8 moves)
                if new_loc in recent_positions:
                    # Apply penalties ONLY if not oscillating
                    if not is_oscillating:
                        # Strong penalty for recently visited squares (prevents tight loops)
                        recent_index = recent_positions.index(new_loc)
                        # More recent = higher penalty
                        recency_penalty = (len(recent_positions) - recent_index) * 200.0
                        score -= (1000.0 + recency_penalty) * desperation_factor

                        # Extra penalty if this creates a loop (going back to same square multiple times)
                        visit_count = recent_positions.count(new_loc)
                        if visit_count > 1:
                            score -= visit_count * 600.0 * desperation_factor

                # CRITICAL: Add STRONG tie-breaking to prevent oscillation
                # Use deterministic factors instead of hash-based randomness
                if my_valid_moves <= 6 or is_oscillating:
                    # Use deterministic positional factors for tie-breaking
                    # Prefer moves that increase distance from recent positions
                    if recent_positions is not None and len(recent_positions) > 0:
                        avg_recent_x = sum(pos[0] for pos in recent_positions[-4:]) / min(4, len(recent_positions))
                        avg_recent_y = sum(pos[1] for pos in recent_positions[-4:]) / min(4, len(recent_positions))
                        dist_from_recent_center = abs(new_loc[0] - avg_recent_x) + abs(new_loc[1] - avg_recent_y)
                        score += dist_from_recent_center * 100.0  # Deterministic tie-breaker

                    # STRONG preference for moves away from recent positions
                    if len(recent_positions) >= 2:
                        # Calculate average of recent positions
                        avg_recent_x = sum(pos[0] for pos in recent_positions[-4:]) / min(4, len(recent_positions))
                        avg_recent_y = sum(pos[1] for pos in recent_positions[-4:]) / min(4, len(recent_positions))
                        dist_from_recent_center = abs(new_loc[0] - avg_recent_x) + abs(new_loc[1] - avg_recent_y)
                        score += dist_from_recent_center * 500.0  # HUGE reward for escaping the area

                    # Additional: prefer corners/edges when stuck (forces movement)
                    if self._is_corner(new_loc):
                        score += 300.0
                    elif self._is_edge(new_loc):
                        score += 150.0

            # Encourage exploration with plain moves (not eggs - eggs can go anywhere)
            if visited_squares is not None:
                # Check if visited_squares is dict (timestamp-based) or set (legacy)
                if isinstance(visited_squares, dict):
                    if new_loc in visited_squares:
                        # Apply penalties ONLY if not oscillating
                        if not is_oscillating:
                            # Decay-based penalty for revisiting squares
                            turns_since_visit = current_turn_count - visited_squares.get(new_loc, 0)
                            if turns_since_visit < 10:
                                # Stronger penalty for recent visits
                                recency_factor = 1.0 - (turns_since_visit / 10.0)
                                score -= 800.0 * recency_factor * desperation_factor  # Increased from 400
                            else:
                                score -= 200.0 * desperation_factor  # Light penalty for old visits

                            # Count how many times we've visited this square recently
                            visit_count = sum(1 for pos in (recent_positions or []) if pos == new_loc)
                            if visit_count > 0:
                                # Penalty for multiple plain visits to same square
                                score -= visit_count * visit_count * 500.0 * desperation_factor  # Increased from 250
                    else:
                        # Good bonus for exploring new squares with plain moves
                        score += 150.0
                elif new_loc in visited_squares:
                    # Apply penalties ONLY if not oscillating
                    if not is_oscillating:
                        # INCREASED penalty for revisiting squares with plain moves
                        score -= 800.0 * desperation_factor  # Increased from 400

                        # Count how many times we've visited this square
                        visit_count = sum(1 for pos in (recent_positions or []) if pos == new_loc)
                        if visit_count > 0:
                            # Penalty for multiple plain visits to same square
                            score -= visit_count * visit_count * 500.0 * desperation_factor  # Increased from 250
                else:
                    # Good bonus for exploring new squares with plain moves
                    score += 150.0

                    # Extra bonus for exploring different regions of the map
                    region_bonus = self._get_region_exploration_bonus(new_loc, visited_squares)
                    score += region_bonus

                    # Bonus for moving away from recently visited areas
                    if recent_positions is not None and len(recent_positions) > 0:
                        min_dist_to_recent = min(
                            abs(new_loc[0] - pos[0]) + abs(new_loc[1] - pos[1])
                            for pos in recent_positions
                        )
                        # Bonus for being far from recently visited squares
                        if min_dist_to_recent >= 4:
                            score += 40.0
                        elif min_dist_to_recent >= 3:
                            score += 20.0
        
        # 7. Encourage exploration toward accessible corners (3x egg value!)
        # Only corners where this chicken can lay eggs (parity match)
        accessible_corners = self._get_accessible_corners(board)
        if accessible_corners:
            # Find closest accessible corner
            min_dist_to_corner = min(
                abs(new_loc[0] - corner[0]) + abs(new_loc[1] - corner[1])
                for corner in accessible_corners
            )
            # Bonus for moving toward accessible corners (especially if not visited)
            if visited_squares is None or new_loc not in visited_squares:
                # Closer to corner = better (max distance is ~14 on 8x8 board)
                corner_bonus = max(0, (14 - min_dist_to_corner) * 5.0)
                score += corner_bonus

                # Extra bonus if we're very close to an accessible corner
                if min_dist_to_corner <= 2:
                    score += 30.0
                elif min_dist_to_corner <= 4:
                    score += 15.0

        # 8. ESCAPE FROM EGG CLUSTERS: If we're near our own eggs, explore away!
        # This prevents circling around eggs we already laid
        # REDUCED penalties to prevent oscillation
        if hasattr(board, 'eggs_player') and board.eggs_player and move_type == MoveType.PLAIN:
            min_dist_to_my_egg = min(
                abs(new_loc[0] - egg[0]) + abs(new_loc[1] - egg[1])
                for egg in board.eggs_player
            )

            # Bonus for moving AWAY from our own eggs (with plain moves)
            if min_dist_to_my_egg >= 5:
                score += 200.0  # Great! Far from our eggs, exploring new territory
            elif min_dist_to_my_egg >= 4:
                score += 120.0  # Good distance
            elif min_dist_to_my_egg >= 3:
                score += 60.0   # Moderate distance
            elif min_dist_to_my_egg <= 1:
                # Very close to our own egg - light penalty only
                score -= 50.0  # Light penalty (was 200!)

        # 9. ESCAPE FROM OWN TURDS: Don't circle around turds we placed!
        # Plain moves should explore away, not revisit turd locations
        # REDUCED penalties to prevent oscillation
        if hasattr(board, 'turds_player') and board.turds_player and move_type == MoveType.PLAIN:
            min_dist_to_my_turd = min(
                abs(new_loc[0] - turd[0]) + abs(new_loc[1] - turd[1])
                for turd in board.turds_player
            )

            # Bonus for moving AWAY from our own turds
            if min_dist_to_my_turd >= 5:
                score += 250.0  # Great! Far from our turds
            elif min_dist_to_my_turd >= 4:
                score += 150.0  # Good distance
            elif min_dist_to_my_turd >= 3:
                score += 80.0  # Moderate distance
            elif min_dist_to_my_turd <= 2:
                # Close to our own turd - light penalty
                score -= 100.0  # Light penalty (was 350!)

            # Adjacent to our own turd squares - moderate penalty
            if new_loc in board.turds_player:
                score -= 200.0  # Moderate penalty (was 500!)

        return score

    def evaluate_position(
        self,
        board: board_module.Board,
        nn_evaluator=None,
        feature_extractor=None,
        trapdoor_tracker=None
    ) -> float:
        """
        Comprehensive position evaluation.

        Uses neural network if available, otherwise falls back to heuristics.
        Returns a score where positive is good for current player.
        """
        # Try neural network first (if available and loaded)
        if nn_evaluator is not None and feature_extractor is not None:
            try:
                import torch

                # Extract features
                features = feature_extractor.extract_features(board, trapdoor_tracker)

                # Convert to tensor
                features_tensor = torch.FloatTensor(features).unsqueeze(0)  # Add batch dimension

                # Get NN prediction
                with torch.no_grad():
                    nn_output = nn_evaluator(features_tensor)
                    nn_score_raw = nn_output.item()

                # NN was trained with normalized scores (roughly [-2, +2])
                # Convert back to heuristic scale (multiply by ~1500)
                nn_score = nn_score_raw * 1500.0

                # Blend with heuristics (80% NN, 20% heuristic for stability)
                heuristic_score = self._get_heuristic_score(board)
                blended_score = 0.8 * nn_score + 0.2 * heuristic_score

                return blended_score

            except Exception as e:
                # NN failed, fall back to heuristics
                pass

        # Fallback: pure heuristic evaluation
        return self._get_heuristic_score(board)

    def _get_heuristic_score(self, board: board_module.Board) -> float:
        """Get heuristic-based score (fallback when NN not available)"""
        # Material advantage (most important)
        my_eggs = board.chicken_player.get_eggs_laid()
        enemy_eggs = board.chicken_enemy.get_eggs_laid()
        egg_diff = (my_eggs - enemy_eggs) * 300.0  # Use improved 300 per egg

        # Mobility advantage - CRITICAL for avoiding traps!
        my_moves = len(board.get_valid_moves())
        board.reverse_perspective()
        enemy_moves = len(board.get_valid_moves())
        board.reverse_perspective()

        # If enemy has NO moves, they lose and we get 5 eggs (1500 points)!
        if enemy_moves == 0:
            mobility_score = 2000.0  # Winning position!
        # If WE have no moves, we lose and enemy gets 5 eggs
        elif my_moves == 0:
            mobility_score = -2000.0  # Losing position!
        else:
            # Normal mobility advantage - very important!
            # Each move difference is worth ~50 points (not 5!)
            # Having more moves = safer from traps + more options
            mobility_score = (my_moves - enemy_moves) * 50.0

            # Extra penalty for low mobility (danger of getting trapped)
            if my_moves <= 2:
                mobility_score -= 200.0  # Very dangerous!
            elif my_moves <= 3:
                mobility_score -= 100.0  # Risky

            # Bonus for reducing enemy mobility (trying to trap them)
            if enemy_moves <= 2:
                mobility_score += 200.0  # We're trapping them!
            elif enemy_moves <= 3:
                mobility_score += 100.0

        # Positional factors
        positional_score = self._evaluate_position_quality(board)

        # Combine scores
        total = egg_diff + mobility_score + positional_score

        return total

    def _evaluate_position_quality(self, board: board_module.Board) -> float:
        """Evaluate positional factors like territory control"""
        score = 0.0

        my_loc = board.chicken_player.get_location()
        enemy_loc = board.chicken_enemy.get_location()

        # Center control
        my_center_dist = self._distance_to_center(my_loc)
        enemy_center_dist = self._distance_to_center(enemy_loc)
        score += (enemy_center_dist - my_center_dist) * 3.0

        # Turd advantage
        my_turds = board.chicken_player.get_turds_left()
        enemy_turds = board.chicken_enemy.get_turds_left()
        score += (my_turds - enemy_turds) * 10.0

        # Egg clusters (eggs close together are harder to block)
        my_egg_cluster = self._count_egg_clusters(board.eggs_player)
        enemy_egg_cluster = self._count_egg_clusters(board.eggs_enemy)
        score += (my_egg_cluster - enemy_egg_cluster) * 5.0

        return score

    def _blocks_valuable_square(
        self,
        turd_loc: Tuple[int, int],
        enemy_loc: Tuple[int, int],
        board: board_module.Board
    ) -> bool:
        """Check if placing a turd here blocks enemy from valuable squares"""
        # Check if turd is between enemy and valuable egg-laying squares
        valuable_squares = self._get_valuable_egg_squares(board)

        for square in valuable_squares:
            # Simple line-of-sight check
            if self._is_between(turd_loc, enemy_loc, square):
                return True

        return False

    def _get_valuable_egg_squares(self, board: board_module.Board) -> List[Tuple[int, int]]:
        """Get list of valuable egg-laying positions"""
        valuable = []

        # Center squares are valuable
        center = self.map_size // 2
        for i in range(center - 1, center + 2):
            for j in range(center - 1, center + 2):
                if 0 <= i < self.map_size and 0 <= j < self.map_size:
                    valuable.append((i, j))

        # Corners are valuable (defensible)
        corners = [
            (0, 0), (0, self.map_size - 1),
            (self.map_size - 1, 0), (self.map_size - 1, self.map_size - 1)
        ]
        valuable.extend(corners)

        return valuable

    def _is_between(
        self,
        point: Tuple[int, int],
        start: Tuple[int, int],
        end: Tuple[int, int]
    ) -> bool:
        """Check if point is roughly between start and end"""
        px, py = point
        sx, sy = start
        ex, ey = end

        # Simple Manhattan distance check
        dist_start_to_end = abs(sx - ex) + abs(sy - ey)
        dist_start_to_point = abs(sx - px) + abs(sy - py)
        dist_point_to_end = abs(px - ex) + abs(py - ey)

        # Point is "between" if total distance is close to direct distance
        return dist_start_to_point + dist_point_to_end <= dist_start_to_end + 2

    def _count_egg_clusters(self, eggs: set) -> int:
        """Count eggs that are adjacent to other eggs (clustering bonus)"""
        cluster_count = 0
        for egg in eggs:
            # Check if this egg has neighbors
            for dx in [-1, 0, 1]:
                for dy in [-1, 0, 1]:
                    if dx == 0 and dy == 0:
                        continue
                    neighbor = (egg[0] + dx, egg[1] + dy)
                    if neighbor in eggs:
                        cluster_count += 1
                        break
        return cluster_count

    def _is_corner(self, loc: Tuple[int, int]) -> bool:
        """Check if location is a corner"""
        x, y = loc
        return (x == 0 or x == self.map_size - 1) and \
               (y == 0 or y == self.map_size - 1)
    
    def _get_accessible_corners(self, board: board_module.Board) -> List[Tuple[int, int]]:
        """
        Get list of corners where this chicken can lay eggs (parity match).
        These corners give 3x egg value, so they're very valuable!
        """
        corners = [
            (0, 0), (0, self.map_size - 1),
            (self.map_size - 1, 0), (self.map_size - 1, self.map_size - 1)
        ]
        
        # Filter to only corners this chicken can lay eggs on
        accessible = []
        for corner in corners:
            if board.chicken_player.can_lay_egg(corner):
                accessible.append(corner)
        
        return accessible

    def _is_center(self, loc: Tuple[int, int]) -> bool:
        """Check if location is in center area"""
        x, y = loc
        center = self.map_size // 2
        return abs(x - center) <= 1 and abs(y - center) <= 1

    def _is_edge(self, loc: Tuple[int, int]) -> bool:
        """Check if location is on the edge"""
        x, y = loc
        return x == 0 or x == self.map_size - 1 or \
               y == 0 or y == self.map_size - 1

    def _distance_to_center(self, loc: Tuple[int, int]) -> float:
        """Manhattan distance to center"""
        x, y = loc
        center = self.map_size / 2.0
        return abs(x - center) + abs(y - center)
    
    def _get_quadrant(self, loc: Tuple[int, int]) -> str:
        """Get which quadrant a location is in (for spreading strategy)"""
        mid = self.map_size / 2.0
        x, y = loc

        if x < mid and y < mid:
            return 'NW'
        elif x < mid and y >= mid:
            return 'NE'
        elif x >= mid and y < mid:
            return 'SW'
        else:
            return 'SE'

    def _count_quadrant_visits(self, loc: Tuple[int, int], visited_squares: set) -> dict:
        """Count how many squares have been visited in each quadrant"""
        quadrant_counts = {'NW': 0, 'NE': 0, 'SW': 0, 'SE': 0}

        for visited in visited_squares:
            quadrant = self._get_quadrant(visited)
            quadrant_counts[quadrant] += 1

        return quadrant_counts

    def _get_region_exploration_bonus(self, loc: Tuple[int, int], visited_squares: set) -> float:
        """
        Give bonus for exploring different regions of the map.
        This encourages spreading out and exploring the whole board.
        """
        if not visited_squares or len(visited_squares) < 2:
            return 0.0
        
        # Divide map into 4 quadrants
        mid = self.map_size / 2.0
        x, y = loc
        
        # Determine which quadrant this location is in
        if x < mid and y < mid:
            region = 'top_left'
        elif x < mid and y >= mid:
            region = 'top_right'
        elif x >= mid and y < mid:
            region = 'bottom_left'
        else:
            region = 'bottom_right'
        
        # Count how many visited squares are in the same region
        same_region_count = 0
        for visited in visited_squares:
            vx, vy = visited
            if vx < mid and vy < mid and region == 'top_left':
                same_region_count += 1
            elif vx < mid and vy >= mid and region == 'top_right':
                same_region_count += 1
            elif vx >= mid and vy < mid and region == 'bottom_left':
                same_region_count += 1
            elif vx >= mid and vy >= mid and region == 'bottom_right':
                same_region_count += 1
        
        # Bonus for exploring less-visited regions
        if same_region_count == 0:
            return 30.0  # First visit to this region
        elif same_region_count <= 2:
            return 15.0  # Early exploration of this region
        else:
            return 0.0  # Already well-explored region

    def find_trapping_moves(
        self,
        board: board_module.Board
    ) -> List[Tuple[Direction, MoveType]]:
        """
        Find moves that can trap the enemy by blocking escape routes.
        """
        if board.chicken_player.get_turds_left() == 0:
            return []

        enemy_loc = board.chicken_enemy.get_location()
        my_loc = board.chicken_player.get_location()
        trapping_moves = []

        # Find turd positions that would block enemy
        for move in board.get_valid_moves():
            if move[1] != MoveType.TURD:
                continue

            direction, _ = move
            turd_loc = loc_after_direction(my_loc, direction)

            if not board.can_lay_turd_at_loc(turd_loc):
                continue

            # Count how many enemy moves this would block
            blocked_count = self._count_blocked_enemy_moves(
                turd_loc, enemy_loc, board
            )

            if blocked_count >= 2:
                trapping_moves.append(move)

        return trapping_moves

    def _count_blocked_enemy_moves(
        self,
        turd_loc: Tuple[int, int],
        enemy_loc: Tuple[int, int],
        board: board_module.Board
    ) -> int:
        """Count how many enemy moves would be blocked by a turd at turd_loc"""
        blocked = 0

        # Turds block adjacent squares
        for direction in [Direction.UP, Direction.DOWN, Direction.LEFT, Direction.RIGHT]:
            potential_move = loc_after_direction(enemy_loc, direction)

            # Check if this move would be blocked by the turd
            # (can't move into turd or squares adjacent to turd)
            if potential_move == turd_loc:
                blocked += 1
            elif abs(potential_move[0] - turd_loc[0]) + abs(potential_move[1] - turd_loc[1]) == 1:
                blocked += 1

        return blocked

